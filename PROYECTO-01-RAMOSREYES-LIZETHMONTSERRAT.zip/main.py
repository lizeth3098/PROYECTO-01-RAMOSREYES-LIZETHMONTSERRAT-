from lifestore_file import lifestore_products, lifestore_sales, lifestore_searches
from tabulate import tabulate



#Usuarios_registrados[usuario,contraseña]
usuarios_registrados=[["Emtech", "Curso"],["Lizeth", "Ramos"]]
print("Este es el sistema de análisis Emtech. Por favor, inicie sesión")
login=input("¿Ya tiene una cuenta? (si/no) ")

#inicio de sesión
while login=="no":
  nuevo_usuario=input("ingrese un nombre de usuario ")
  nueva_contrasena=input("ingrese una contraseña ")
  usuarios_registrados.append([nuevo_usuario, nueva_contrasena])
  print("se ha registrado con éxito")
  login="si"

usuario_login = input("Ingresa el usuario: ")
password = input("Ingresa la contraseña: ")

registro=0
intento = 0

while login=="si":
  #intentos de login para ingresar datos correctos
  while registro != 1 and intento < 2:
    for usuario in usuarios_registrados:
      if usuario[0] == usuario_login and usuario[1]==password:
        registro = 1
        login="no"
    
    if registro == 0:
      print("Datos incorrectos")
      usuario_login = input("Ingresa nuevamente el usuario: ")
      password = input("Ingresa nuevamente la contraseña: ")
      intento += 1



  ## OPERACIONES A REALIZAR PARA ANÁLISIS 
  if registro == 1:
    print("Sesión iniciada")
    accion=0
    while accion==0:
      #Menú de opciones a analizar
      
      accion= input("""
      
      ingrese el número de la opción de lo que quiere revisar
      
      1. Ver los productos con mayores ventas
      2. Ver los productos con mayores búsquedas
      3. Ver los productos menos vendidos por categorías
      4. Ver los productos menos buscados por categorías
      5. Ver los productos con mejores reseñas
      6. Ver los productos con peores reseñas
      7.Total de ingresos, ventas promedio mensuales y meses con más ventas al año
      8.Salir
      
      """)

      #Ver los productos con mayores ventas
      if accion=="1":
        print(" 1. Ver los productos con mayores ventas")
        contador = 0
        venta_productos = []

        #contar la cantidad de ventas por producto
        for producto in lifestore_products:
          for venta in lifestore_sales:
            if producto[0] == venta[1]:
              contador += 1
          venta_productos.append([producto[0], contador, producto[3]]) # [id_producto, num_ventas,categoria]
          contador = 0
            
        #ordenar las ventas de mayor a menor cantidad
        ventas_ordenadas=[]
      
        while venta_productos:
          minimo=venta_productos[0][1]
          lista_actual= venta_productos[0]
          for venta in venta_productos:
            if venta[1]> minimo:
              minimo=venta[1]
              lista_actual=venta
          ventas_ordenadas.append(lista_actual)
          venta_productos.remove(lista_actual)
        
        #mostrar los resultados
        print("\nEl top 10 de los productos más vendidos es: \n")
        productos_vendidos=0
        for valor in ventas_ordenadas:
          if productos_vendidos<10:
            print('El producto ', valor[0], ' se vendió ', valor[1], ' veces, de la categoría ',valor[2])
            productos_vendidos+=1
            
        accion=0
        print("\nPara análisis de todas las ventas:\n")
        
        print(tabulate(ventas_ordenadas, headers=["Producto", "Cantidad", "Categoria"]))
      
    
      elif accion=="2":
        print("2. Ver los productos con mayores búsquedas")
        contador = 0
        busqueda_productos = []
        #conteo de cantidad de búsquedas
        for producto in lifestore_products:
          for busqueda in lifestore_searches:
            if producto[0] == busqueda[1]:
              contador += 1
          busqueda_productos.append([producto[0], contador, producto[3]]) # [id_producto, num_ventas, categoria]
          contador = 0
           
        #ordenar cantidad de búsquedas de mayor a menor 
        busquedas_ordenadas=[]
      
        while busqueda_productos:
          minimo=busqueda_productos[0][1]
          lista_actual= busqueda_productos[0]
          for buscar in busqueda_productos:
            if buscar[1]> minimo:
              minimo=buscar[1]
              lista_actual=buscar
          busquedas_ordenadas.append(lista_actual)
          busqueda_productos.remove(lista_actual)
        
        #imprimir los 10 productos más buscados
        print("\nLos 10 productos con mayores búsquedas:\n") 
        productos_buscados=0
        for valor in busquedas_ordenadas:
          if productos_buscados<10:
            print('El producto ', valor[0], ' se buscó ', valor[1],' veces', ' de la categoría '+ valor[2])
            productos_buscados+=1
        
        print("\nPara análisis de todas las búsquedas:\n")       
        
        print(tabulate(busquedas_ordenadas, headers=["Producto", "Búsquedas", "Categoria"]))
        accion=0
      
      elif accion=="3":
        print('3. Ver los productos menos vendidos por categorías')
        contador = 0
        venta_productos = []
        for producto in lifestore_products:
          for venta in lifestore_sales:
            if producto[0] == venta[1]:
              contador += 1
          venta_productos.append([producto[0], contador, producto[3]]) # [id_producto, num_ventas,categoria]
          contador = 0
        ventas_ordenadas=[]
      
        while venta_productos:
          minimo=venta_productos[0][1]
          categorias=venta_productos[0][2]
          lista_actual= venta_productos[0]
          for venta in venta_productos:
            if venta[1] > minimo:
              minimo=venta[1]
              lista_actual=venta
          ventas_ordenadas.append(lista_actual)
          venta_productos.remove(lista_actual)
        ventas_ordenadas_categoria=[]
        while ventas_ordenadas:
          categorias=ventas_ordenadas[0][2]
          lista_actual= ventas_ordenadas[0]
          for venta in ventas_ordenadas:
            if venta[2] == categorias:
              categorias=venta[2]
              lista_actual=venta
          ventas_ordenadas_categoria.append(lista_actual)
          ventas_ordenadas.remove(lista_actual)
        print("\nPara análisis de los productos con menos ventas por categorías ordenados de menor a mayor:\n")       
        
        print(tabulate(ventas_ordenadas_categoria, headers=["Producto", "ventas", "Categoria"]))
        
        accion=0

      #Productos menos buscados por categorías
      elif accion=="4":
        print("4. Ver los productos menos buscados por categorías")
        contador = 0
        busqueda_productos = []
        for producto in lifestore_products:
          for busqueda in lifestore_searches:
            if producto[0] == busqueda[1]:
              contador += 1
          busqueda_productos.append([producto[0], contador, producto[3]]) # [id_producto, num_ventas,categoria]
          contador = 0
          
        busquedas_ordenadas=[]
      
        while busqueda_productos:
          minimo=busqueda_productos[0][1]
          categorias=busqueda_productos[0][2]
          lista_actual= busqueda_productos[0]
          for buscar in busqueda_productos:
            if buscar[1] > minimo:
              minimo=buscar[1]
              lista_actual=buscar
          busquedas_ordenadas.append(lista_actual)
          busqueda_productos.remove(lista_actual)
        busquedas_ordenadas_categoria=[]
        while busquedas_ordenadas:
          categorias=busquedas_ordenadas[0][2]
          lista_actual= busquedas_ordenadas[0]
          for buscar in busquedas_ordenadas:
            if buscar[2] == categorias:
              categorias=buscar[2]
              lista_actual=buscar
          busquedas_ordenadas_categoria.append(lista_actual)
          busquedas_ordenadas.remove(lista_actual)

        print("\nPara análisis de los productos con menos búsquedas por categoría ordenados de menor a mayor:\n")       
        
        print(tabulate(busquedas_ordenadas_categoria, headers=["Producto", "búsquedas", "Categoria"]))
        accion=0
      


     
      #productos con mejores reseñas
      elif accion=='5':
        print("5. Ver los productos con mejores reseñas")
        info=[]#producto, cantidad ventas, calificación, devoluciones
        for producto in lifestore_products:
          info.append([producto[0],0,0,0]) #[producto, cantidad de ventas, calificación, devoluciones]
        for producto in info:
          id=producto[0]
          for score in lifestore_sales:
            if id==score[1]:
              info[id-1][2]+=score[2]
              info[id-1][1]+=1
              info[id-1][3]+=score[4]
        
        info2=[]#producto, cantidad ventas, evaluación, devoluciones
        for producto in lifestore_products:
          info2.append([producto[0],0,0,0]) #[producto, cantidad de ventas, calificación, devoluciones]
        for producto in info2:
          id=producto[0]
          for promedio in info:
            if id==promedio[0]:
              info2[id-1][1]=promedio[1]
              info2 [id-1][3]=promedio[3]
              if promedio[2]>0:
                info2 [id-1][2]=promedio[2]/promedio[1]
       
        resenas_ordenadas=[]

        while info2:
          minimo=info2[0][2]
          lista_actual= info2[0]
          for producto in info2:
            if producto[2] > minimo:
              minimo=producto[2]
              lista_actual=producto
          resenas_ordenadas.append(lista_actual)
          info2.remove(lista_actual)
        #presentación de los 20 productos mejor calificados
        print( '\n Los 20 productos con mejor calificación promedio \n')

        productos_vendidos=0
        for valor in resenas_ordenadas:
          if productos_vendidos<=20:
            print('Producto ', valor[0], ' ventas ', valor[1], 'Calificación ',valor[2], ' Devoluciones ', valor[3])
            productos_vendidos+=1

        print( '\n Análisis de todos los productos según su calificación promedio \n')

        print(tabulate(resenas_ordenadas, headers=["Producto", "Ventas", "Evaluación","Devoluciones"]))
        
        accion=0

     
      elif accion=='6':
        print("6. Ver los productos con peores reseñas")
        info=[]#producto, cantidad ventas, calificación, devoluciones
        for producto in lifestore_products:
          info.append([producto[0],0,0,0]) #[producto, cantidad de ventas, calificación, devoluciones]
        for producto in info:
          id=producto[0]
          for score in lifestore_sales:
            if id==score[1]:
              info[id-1][2]+=score[2]
              info[id-1][1]+=1
              info[id-1][3]+=score[4]
              
        4
        info2=[]#producto, cantidad ventas, promedio evalución, devoluciones
        for producto in lifestore_products:
          info2.append([producto[0],0,0,0]) #[producto, cantidad de ventas, calificación promedio, devoluciones]
        for producto in info2:
          id=producto[0]
          for promedio in info:
            if id==promedio[0]:
              info2[id-1][1]=promedio[1]
              info2 [id-1][3]=promedio[3]
              if promedio[2]>0:
                info2 [id-1][2]=promedio[2]/promedio[1]
        
        resenas_ordenadas=[]

        while info2:
          minimo=info2[0][2]
          lista_actual= info2[0]
          for producto in info2:
            if producto[2] < minimo:
              minimo=producto[2]
              lista_actual=producto
          resenas_ordenadas.append(lista_actual)
          info2.remove(lista_actual)

        
        print( '\n Los 50 productos con las calificaciones más bajas \n')

        productos_vendidos=0
        for valor in resenas_ordenadas:
          if productos_vendidos<=50:
            print('Producto ', valor[0], ' Ventas ', valor[1], ' Calificación ',valor[2], ' Devoluciones ', valor[3])
            productos_vendidos+=1
        print( '\n Total de productos según las menores calificaciones \n')
        print(tabulate(resenas_ordenadas, headers=["Producto", "Ventas", "Evaluación","Devoluciones"]))

        accion=0

      #Ingresos, ventas promedio mensuales
      elif accion=='7':
        print("7.Total de ingresos, ventas promedio mensuales y meses con más ventas al año")
        """
This is the LifeStore_SalesList data:

lifestore_searches = [id_search, id product]
lifestore_sales = [id_sale, id_product, score (from 1 to 5), date, refund (1 for true or 0 to false)]
lifestore_products = [id_product, name, price, category, stock]
"""
        info=[]
              
        for producto in lifestore_sales:
           info.append([producto[1], producto[3][3:5],producto[3][6:10],producto[4],0,0])#0producto, 1mes, 2año, 3devolución, 4costo, 5ganancia
        i=0
        for producto in info:
          id=producto[0]
          
        
          for venta in lifestore_products:
            if id==venta[0]:
              info[i][4]=venta[2]
              if info[i][3]==1:
                info[i][5]=0
              else:
                info[i][5]=info[i][4]
              i+=1
          
        #orden por años
        year_ordenadas=[]  
        while info:
          year2=int(info[0][2])
          lista_actual= info[0]
          for fecha in info:
            if int(fecha[2])> int(year2):
              year2=fecha[2]
              lista_actual=fecha
          year_ordenadas.append(lista_actual)
          info.remove(lista_actual)
        
        #orden por meses
        mes_ordenados=[]
        while year_ordenadas:
          mes2= int(year_ordenadas[0][1])
          lista_actual= year_ordenadas[0]
          for mes in year_ordenadas:
            if int(mes[1])> int(mes2):
              mes2=mes[1]
              lista_actual=mes
          mes_ordenados.append(lista_actual)
          year_ordenadas.remove(lista_actual)

        i=0
        ganancia=0
        #Cálculo del total de ganancias
        for registro in mes_ordenados:
          ganancia+=mes_ordenados[i][5]
          i+=1
          #total_ingresos.append(ganancia)
        print("\nEl total de ganancias de la empresa es de: $",ganancia,'.00\n')

        i=0
        ganancia=0
        mes=12
        total=0
        ventas_por_mes=[]#mes,ventas
        for producto in mes_ordenados:
          #mes=mes-1
          ganancia=0
          mes=int(producto[1])
          if int(producto[1])==int(mes):
            ganancia+=producto[5]
            total+=ganancia
        
          ventas_por_mes.append([int(producto[1]),ganancia])
        
        i=0
        ganancia=0
        mes=12
        total=0
        #ventas_por_mes=[]#mes,ventas
        for producto in mes_ordenados:
          #mes=mes-1
          ganancia=0
          mes=int(producto[1])
          if int(producto[1])==int(mes):
            ganancia+=producto[5]
            total+=ganancia
        
        ganancia=0
        i=0
        while mes>0 and mes<12:
          for venta in ventas_por_mes:
            if venta[0]==mes:
              ganancia+=venta[1]
            
          ganancia=0
          mes-=1



        mes=11
        ganancia=0
        i=0
        ventas_mensual_promedio=[]
        cantidad=0
        print( '\n Ventas mensuales por ganancia total y promedio \n')
        while mes>0 and mes<12:
          for venta in ventas_por_mes:
            if venta[0]==mes:
              ganancia+=venta[1]
              cantidad+=1
            if ganancia>0:
              promedio=ganancia/cantidad
            else:
              promedio=0
          ventas_mensual_promedio.append([mes,cantidad,ganancia,promedio])
          cantidad=0


          
          #print("Mes",mes," Ventas $",ganancia,'.00 Promedio ',promedio)
          ganancia=0
          mes-=1  

        #print( '\n Ventas por mes \n')
        print(tabulate(ventas_mensual_promedio,headers=["Mes", "Ventas", "Ganancia","Promedio"]))

        promedio_ordenados=[]
        while ventas_mensual_promedio:
          maximo=ventas_mensual_promedio[0][1]
          lista_actual= ventas_mensual_promedio[0]
          for venta in ventas_mensual_promedio:
            if venta[1]> maximo:
              maximo=venta[1]
              lista_actual=venta
          promedio_ordenados.append(lista_actual)
          ventas_mensual_promedio.remove(lista_actual)


        
        print(" \nOrden de los meses según las mayores ganancias totales obtenidas:  \n")
        productos_vendidos=0
        #while productos_vendidos<10:
        for valor in promedio_ordenados:
          if productos_vendidos<=12:
            print('Mes ', valor[0], ' Cantidad de ventas ', valor[1], ' Ganancia ',valor[2])
            productos_vendidos+=1

        print( '\n Ventas por mes ordenados por ganancias promedio \n')
        print(tabulate(promedio_ordenados,headers=["Mes", "Ventas","Ganancias", "Promedio"]))


        accion=0


      elif accion=='8':
        break  



    
  else:
    print("Datos incorrectos, acceso denegado")
    break
